import React, { useState, useEffect, useMemo } from 'react';
import { CategoryKey, ContentItem, SingleVideo, Series, Episode } from './types';
import { CATEGORIES } from './constants';
import VideoPlayer from './components/VideoPlayer';

// ====================================================================================
// == Інструкція для синхронізації контенту з GitHub
// ====================================================================================
// 1. Створіть ПУБЛІЧНИЙ репозиторій на GitHub.
// 2. У репозиторії створіть JSON файли для кожної категорії. Назви файлів
//    мають відповідати ключам категорій, наприклад:
//    - `series.json` (обов'язково має структуру з сезонами/епізодами)
//    - `movies.json` (має структуру звичайних відео)
//    (приклади структури цих файлів є в папці `data` цього проекту).
// 3. Перейдіть до будь-якого з цих файлів на GitHub і натисніть "Raw".
// 4. Скопіюйте URL, але видаліть назву файлу в кінці. Це буде ваша базова URL-адреса.
//    Вона має закінчуватися слешем `/`.
//    Приклад: `https://raw.githubusercontent.com/sastamaa/utainies_app/main/`
// 5. Замініть URL-адресу-заглушку нижче на скопійовану вами.
// ====================================================================================
const GITHUB_CONTENT_BASE_URL = 'https://raw.githubusercontent.com/sastamaa/utainies_app/main/';


const Header: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <header className="text-center p-4 sm:p-6">
    <h1 className="text-4xl sm:text-6xl font-bold text-sky-800 tracking-tight" style={{ fontFamily: "'Comic Sans MS', 'Chalkboard SE', 'Marker Felt', sans-serif" }}>
      {children}
    </h1>
  </header>
);

const BackButton: React.FC<{ onClick: () => void, text: string }> = ({ onClick, text }) => (
  <button
    onClick={onClick}
    className="absolute top-4 left-4 z-10 bg-white/80 backdrop-blur-sm text-gray-800 font-bold py-2 px-4 rounded-full shadow-lg hover:bg-white transition-transform duration-200 hover:scale-105 flex items-center"
  >
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
    </svg>
    {text}
  </button>
);


const App: React.FC = () => {
  const [content, setContent] = useState<ContentItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<CategoryKey | null>(null);
  const [selectedSeries, setSelectedSeries] = useState<Series | null>(null);
  const [currentEpisode, setCurrentEpisode] = useState<Episode | null>(null);
  const [currentPlaylist, setCurrentPlaylist] = useState<Episode[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  
  useEffect(() => {
    const fetchAllContent = async () => {
      setIsLoading(true);
      if (GITHUB_CONTENT_BASE_URL.includes('YOUR_USERNAME') || GITHUB_CONTENT_BASE_URL.includes('sastamaa/utainies_app/main')) {
          console.warn("Використовується URL-адреса за замовчуванням. Розкоментуйте перевірку, якщо у вас є своя.");
        // const errorMessage = 'Будь ласка, налаштуйте базову URL-адресу для контенту в файлі App.tsx';
        // setError(errorMessage);
        // setIsLoading(false);
        // return;
      }
      
      setError(null);
      
      const categoryKeys = Object.keys(CATEGORIES) as CategoryKey[];
      
      try {
        const fetchPromises = categoryKeys.map(key => {
            const url = `${GITHUB_CONTENT_BASE_URL}${key}.json?t=${new Date().getTime()}`; // Cache busting
            return fetch(url, { cache: 'no-store' })
                .then(response => {
                    if (response.ok) return response.json();
                    if (response.status === 404) {
                       console.warn(`Файл для категорії '${key}' не знайдено. Пропускаємо.`);
                       return [];
                    }
                    throw new Error(`Помилка завантаження ${key}: ${response.statusText}`);
                })
                .catch(err => {
                    console.error(`Не вдалося завантажити категорію ${key}:`, err.message);
                    return [];
                });
        });

        const results = await Promise.all(fetchPromises);
        const allContent = results.flat() as ContentItem[];

        if (allContent.length === 0 && !error) {
             setError('Не вдалося завантажити жодного контенту. Перевірте посилання на GitHub та наявність файлів.');
        } else {
             setContent(allContent);
        }
        
      } catch (e) {
         console.error("Сталася загальна помилка під час завантаження даних:", e);
         setError('Не вдалося завантажити контент. Перевірте Інтернет-з\'єднання.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchAllContent();
  }, []);

  const handleSelectCategory = (key: CategoryKey) => {
    setSelectedCategory(key);
    setSelectedSeries(null);
    setCurrentEpisode(null);
  };
  
  const handleContentItemClick = (item: ContentItem) => {
    if (item.contentType === 'series') {
        setSelectedSeries(item);
    } else {
        setCurrentEpisode(item as SingleVideo);
        setCurrentPlaylist([]);
    }
  };
  
  const handleSelectEpisode = (episode: Episode, series: Series) => {
    const playlist = series.seasons.flatMap(s => s.episodes);
    setCurrentPlaylist(playlist);
    setCurrentEpisode(episode);
  };
  
  const handleNextEpisode = () => {
    if (!currentEpisode || currentPlaylist.length === 0) return;
    const currentIndex = currentPlaylist.findIndex(e => e.id === currentEpisode.id);
    if (currentIndex > -1 && currentIndex < currentPlaylist.length - 1) {
      setCurrentEpisode(currentPlaylist[currentIndex + 1]);
    }
  };

  const handlePrevEpisode = () => {
    if (!currentEpisode || currentPlaylist.length === 0) return;
    const currentIndex = currentPlaylist.findIndex(e => e.id === currentEpisode.id);
    if (currentIndex > 0) {
      setCurrentEpisode(currentPlaylist[currentIndex - 1]);
    }
  };
  
  const handleBackToCategories = () => {
    setSelectedCategory(null);
  };

  const handleBackToGrid = () => {
    setSelectedSeries(null);
  };

  const handleClosePlayer = () => {
    setCurrentEpisode(null);
    setCurrentPlaylist([]);
  };

  const filteredContent = useMemo(() => {
    if (!selectedCategory) return [];
    return content.filter(v => v.category === selectedCategory);
  }, [content, selectedCategory]);

  const renderContent = () => {
    if (isLoading) {
       return <div className="flex justify-center items-center h-screen text-2xl font-bold text-sky-700">Завантаження...</div>;
    }
    
    if (error) {
      return (
        <div className="flex items-center justify-center h-screen p-4">
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg max-w-lg text-center" role="alert">
            <strong className="font-bold block">Помилка!</strong>
            <span className="block mt-1">{error}</span>
          </div>
        </div>
      );
    }
    
    if (currentEpisode) {
      const isPlaylist = currentPlaylist.length > 0;
      return <VideoPlayer 
        episode={currentEpisode} 
        onClose={handleClosePlayer} 
        onNext={isPlaylist ? handleNextEpisode : undefined}
        onPrev={isPlaylist ? handlePrevEpisode : undefined}
      />;
    }

    if (selectedSeries) {
      return (
         <div className="relative min-h-screen w-full animate-fade-in p-4">
            <BackButton onClick={handleBackToGrid} text="Назад до списку" />
            <Header>{selectedSeries.title}</Header>
            <div className="max-w-4xl mx-auto">
              {selectedSeries.seasons.map(season => (
                <div key={season.season} className="mb-8">
                  <h2 className="text-3xl font-bold text-sky-700 mb-4 border-b-2 border-sky-200 pb-2">Сезон {season.season}</h2>
                   <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                      {season.episodes.map(episode => (
                         <div key={episode.id} onClick={() => handleSelectEpisode(episode, selectedSeries)} className="cursor-pointer group flex flex-col items-center text-center">
                            <div className="w-full aspect-video bg-sky-200 rounded-lg flex items-center justify-center text-sky-500 mb-2 shadow-lg group-hover:shadow-xl group-hover:scale-105 transition-transform duration-200">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>
                            </div>
                            <p className="font-semibold text-sky-800 group-hover:text-pink-500">{episode.title}</p>
                         </div>
                      ))}
                   </div>
                </div>
              ))}
            </div>
         </div>
      );
    }

    if (selectedCategory) {
      const categoryInfo = CATEGORIES[selectedCategory];
      return (
        <div className="relative min-h-screen w-full animate-fade-in">
          <BackButton onClick={handleBackToCategories} text="До категорій" />
          <Header>{categoryInfo.name}</Header>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 p-4">
            {filteredContent.map((item) => (
              <div
                key={item.id}
                onClick={() => handleContentItemClick(item)}
                className="group cursor-pointer aspect-video bg-white rounded-xl shadow-lg hover:shadow-2xl overflow-hidden transform hover:-translate-y-2 transition-all duration-300"
              >
                <div className="relative w-full h-full">
                  <img src={item.thumbnail} alt={item.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/30 group-hover:bg-black/50 transition-colors duration-300 flex items-center justify-center">
                     <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>
                     <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white/70 group-hover:text-white group-hover:scale-110 transition-transform duration-300" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                     </svg>
                  </div>
                  {item.contentType === 'series' && (
                    <div className="absolute top-2 right-2 bg-purple-500 text-white text-xs font-bold py-1 px-2 rounded-full">Серіал</div>
                  )}
                  <p className="absolute bottom-0 left-0 right-0 text-white font-bold p-2 text-center text-sm truncate bg-black/40">
                    {item.title}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    }
    
    return (
      <div className="animate-fade-in">
        <Header>UTainies</Header>
        <div className="flex flex-wrap justify-center items-center gap-6 p-6">
          {Object.values(CATEGORIES).map((cat) => (
            <button
              key={cat.key}
              onClick={() => handleSelectCategory(cat.key)}
              className={`flex flex-col items-center justify-center w-40 h-40 sm:w-48 sm:h-48 rounded-2xl text-white font-bold text-2xl shadow-lg transform transition-transform duration-300 hover:scale-110 hover:shadow-2xl ${cat.color} ${cat.hoverColor}`}
            >
              <div className="mb-2">{cat.icon}</div>
              <span>{cat.name}</span>
            </button>
          ))}
        </div>
      </div>
    );
  };
  
  return (
      <main className="min-h-screen w-full bg-sky-100 overflow-x-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20"></div>
        <div className="relative">
          {renderContent()}
        </div>
      </main>
  );
};

export default App;
